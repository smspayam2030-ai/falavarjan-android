package ir.falavarjan.portal

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.loadsImagesAutomatically = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(PortalBridge(), "PortalNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class PortalBridge {
        @JavascriptInterface fun getJson(base: String, path: String, callbackId: String) {
            thread {
                var result: String
                try {
                    val cleanBase = base.trim().trimEnd('/')
                    if (!cleanBase.startsWith("https://") && !cleanBase.startsWith("http://")) throw Exception("آدرس سایت باید با https:// شروع شود")
                    val full = cleanBase + "/wp-json/" + path.trimStart('/')
                    val conn = URL(full).openConnection() as HttpURLConnection
                    conn.requestMethod = "GET"
                    conn.connectTimeout = 12000
                    conn.readTimeout = 15000
                    conn.setRequestProperty("Accept", "application/json")
                    conn.setRequestProperty("User-Agent", "FalavarjanPortalAndroid/1.0")
                    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
                    result = JSONObject().put("ok", conn.responseCode in 200..299).put("status", conn.responseCode).put("body", body).toString()
                    conn.disconnect()
                } catch (e: Exception) {
                    result = JSONObject().put("ok", false).put("error", e.message ?: "خطا در اتصال").toString()
                }
                runOnUiThread {
                    web.evaluateJavascript("window.__apiDone(${JSONObject.quote(callbackId)}, ${JSONObject.quote(result)})", null)
                }
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized) web.evaluateJavascript("window.goBack()", null) else super.onBackPressed()
    }
}
