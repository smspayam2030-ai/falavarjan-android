# اپلیکیشن اندروید پرتال شهری فلاورجان

این پوشه یک پروژهٔ Android Studio (کاتلین + WebView محلی) است که ظاهر فارسی و راست‌چین، آیکون‌های اختصاصی داخلی و اتصال به REST API افزونهٔ پرتال را دارد.

## نکتهٔ مهم
- آدرس پیش‌فرض طبق مستندات داخل افزونه `https://newsfalavarjan.ir` است و از صفحهٔ تنظیمات اپ قابل تغییر است.
- مسیرهای استفاده‌شده: `fcp/v1/home`, `fcp/v1/search`, `nfp/v1/news`, `nfp/v1/items/{type}` و `shohada/v1/today`.
- وجود و فعال بودن هر endpoint به ماژول‌های فعال در وردپرس و تنظیمات پیوند یکتا بستگی دارد.
- این خروجی، **پروژهٔ منبع Android Studio** است؛ APK امضاشده نیست. در این محیط Android SDK/Gradle نصب نبود، بنابراین APK ساخته و روی دستگاه آزمایش نشده است.

## ساخت APK
1. Android Studio را باز کنید و این پوشه را با Open انتخاب کنید.
2. اجازه دهید Gradle Sync تمام شود (Android SDK 35 لازم است).
3. از منوی Build گزینهٔ Build APK(s) را انتخاب کنید.
4. اگر سایت شما آدرس دیگری دارد، در اپ به تنظیمات بروید و آدرس اصلی سایت را تغییر دهید.

## تست API افزونه
- `https://YOUR-SITE/wp-json/fcp/v1/manifest`
- `https://YOUR-SITE/wp-json/fcp/v1/home`
- `https://YOUR-SITE/wp-json/nfp/v1/news`

نام اپ: پرتال شهری فلاورجان · شناسه: `ir.falavarjan.portal`
